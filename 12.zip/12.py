import requests
import json
import tkinter as tk
from tkinter import messagebox

def get_repo_data():
    repo_name = entry.get()
    repo_url = f"https://api.github.com/repos/{repo_name}"
    
    response = requests.get(repo_url)
    
    if response.status_code == 200:
        repo_data = response.json()
        
        filtered_data = {
            'company': repo_data.get('owner', {}).get('company'),
            'created_at': repo_data.get('created_at'),
            'email': repo_data.get('owner', {}).get('email'),
            'id': repo_data.get('id'),
            'name': repo_data.get('name'),
            'url': repo_data.get('url')
        }
        
        with open(f"{repo_name.replace('/', '_')}_data.json", "w") as file:
            json.dump(filtered_data, file, indent=4)
        
        messagebox.showinfo("Успех", f"Данные сохранены в файл {repo_name.replace('/', '_')}_data.json")
    else:
        messagebox.showerror("Ошибка", f"Ошибка при запросе данных: {response.status_code}")

root = tk.Tk()
root.title("GitHub Repo Info")

label = tk.Label(root, text="Введите имя репозитория (kubernetes/kubernetes):")
label.pack(pady=10)

entry = tk.Entry(root, width=50)
entry.pack(pady=10)

button = tk.Button(root, text="Получить данные", command=get_repo_data)
button.pack(pady=20)

root.mainloop()